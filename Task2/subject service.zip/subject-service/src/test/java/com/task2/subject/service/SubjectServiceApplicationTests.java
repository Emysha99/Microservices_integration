package com.task2.subject.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SubjectServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
